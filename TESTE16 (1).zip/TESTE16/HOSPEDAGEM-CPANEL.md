# 🌐 Guia de Hospedagem para cPanel

## 📁 Arquivos para Upload

Você precisa fazer upload dos seguintes arquivos para a pasta `public_html` do seu cPanel:

### Arquivos Obrigatórios:
```
public_html/
├── index.html          (Página principal)
├── app.js             (JavaScript principal)
├── sw.js              (Service Worker para PWA)
├── manifest.json      (Manifest PWA)
└── .htaccess          (Configurações do servidor)
```

### Como fazer upload:

1. **Acesse o Gerenciador de Arquivos** no cPanel
2. **Navegue até public_html**
3. **Faça upload** dos 4 arquivos da pasta `public-static/`
4. **Crie o arquivo .htaccess** (veja abaixo)

## ⚙️ Arquivo .htaccess

Crie um arquivo `.htaccess` na pasta `public_html` com o seguinte conteúdo:

```apache
# Força HTTPS (recomendado para PWA)
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Configuração PWA
<IfModule mod_mime.c>
    AddType application/manifest+json .webmanifest .json
    AddType text/cache-manifest .appcache
</IfModule>

# Headers para PWA
<IfModule mod_headers.c>
    Header set Service-Worker-Allowed "/"
    Header set Cache-Control "no-cache" env=no_cache
</IfModule>

# Compressão
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/json
</IfModule>

# Cache para recursos estáticos
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
</IfModule>
```

## 🎯 Funcionalidades Incluídas

### ✅ **Funciona Offline**
- App instalável no celular
- Service Worker para cache
- Funciona sem conexão internet

### ✅ **Dados Locais**
- 6 cidades da região BH Norte
- 8 categorias de empresas
- Exemplos de empresas reais
- Linhas de ônibus principais

### ✅ **Recursos Mobile**
- Design responsivo
- Navegação touch-friendly
- Install prompt automático
- PWA completo

### ✅ **Funcionalidades**
- Busca inteligente
- Filtros por categoria/cidade
- Informações de contato
- Integração com Google Maps
- Horários de ônibus

## 🚀 Testando

Após o upload, acesse:
- `https://seudominio.com` - Página principal
- Teste a instalação PWA no celular
- Verifique se funciona offline

## 📱 Instalação no Celular

1. **Acesse o site** no navegador mobile
2. **Aguarde o prompt** de instalação (5 segundos)
3. **Clique em "Instalar"**
4. **App será adicionado** à tela inicial

## 🔧 Customização

Para personalizar o conteúdo:

### Editar Empresas:
No arquivo `app.js`, seção `appData.businesses`

### Editar Cidades:
No arquivo `app.js`, seção `appData.cities`

### Editar Linhas de Ônibus:
No arquivo `app.js`, seção `appData.busLines`

### Alterar Cores:
No arquivo `index.html`, seção `<style>`

## 🎨 Benefícios da Versão Estática

### ✅ **Vantagens:**
- Funciona em qualquer hospedagem
- Carregamento super rápido
- Não depende de banco de dados
- Custos mínimos de hospedagem
- PWA instalável

### 📝 **Limitações:**
- Dados fixos (não dinâmicos)
- Sem painel administrativo
- Atualizações manuais no código

## 🌟 Resultado Final

Um **Guia Comercial BH Norte** completo e profissional que:
- ✅ Funciona em qualquer celular
- ✅ Pode ser instalado como app
- ✅ Funciona offline
- ✅ Design moderno e responsivo
- ✅ Fácil de usar e navegar

Perfeito para divulgar empresas locais da região BH Norte!