interface NominatimResult {
  place_id: number;
  licence: string;
  osm_type: string;
  osm_id: number;
  lat: string;
  lon: string;
  display_name: string;
  class: string;
  type: string;
  importance: number;
  address?: {
    house_number?: string;
    road?: string;
    neighbourhood?: string;
    suburb?: string;
    city?: string;
    state?: string;
    postcode?: string;
    country?: string;
    country_code?: string;
  };
}

interface TouristAttraction {
  id: string;
  name: string;
  description: string;
  category: string;
  lat: number;
  lon: number;
  address: string;
  city: string;
  state: string;
  rating?: number;
  images?: string[];
  opening_hours?: string;
  contact?: {
    phone?: string;
    website?: string;
    email?: string;
  };
}

interface MapLocation {
  lat: number;
  lon: number;
  name: string;
  address: string;
}

class MapsService {
  private readonly NOMINATIM_BASE_URL = 'https://nominatim.openstreetmap.org';
  private readonly USER_AGENT = 'BusScheduleApp/1.0 (contact@busschedule.app)';
  
  // Rate limiting: 1 request per second for Nominatim
  private lastRequestTime = 0;
  private readonly MIN_REQUEST_INTERVAL = 1000; // 1 second

  private async rateLimitedRequest(url: string): Promise<Response> {
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    
    if (timeSinceLastRequest < this.MIN_REQUEST_INTERVAL) {
      const waitTime = this.MIN_REQUEST_INTERVAL - timeSinceLastRequest;
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    
    this.lastRequestTime = Date.now();
    
    return fetch(url, {
      headers: {
        'User-Agent': this.USER_AGENT,
      },
    });
  }

  async geocodeAddress(address: string, city?: string, state?: string): Promise<MapLocation | null> {
    try {
      let query = address;
      if (city) query += `, ${city}`;
      if (state) query += `, ${state}`;
      query += ', Brasil';

      const url = `${this.NOMINATIM_BASE_URL}/search?` + new URLSearchParams({
        q: query,
        format: 'json',
        countrycodes: 'br',
        limit: '1',
        addressdetails: '1',
      });

      const response = await this.rateLimitedRequest(url);
      
      if (!response.ok) {
        throw new Error(`Geocoding failed: ${response.status}`);
      }

      const results: NominatimResult[] = await response.json();
      
      if (results.length === 0) {
        return null;
      }

      const result = results[0];
      return {
        lat: parseFloat(result.lat),
        lon: parseFloat(result.lon),
        name: result.display_name,
        address: result.display_name,
      };
    } catch (error) {
      console.error('Geocoding error:', error);
      return null;
    }
  }

  async reverseGeocode(lat: number, lon: number): Promise<MapLocation | null> {
    try {
      const url = `${this.NOMINATIM_BASE_URL}/reverse?` + new URLSearchParams({
        lat: lat.toString(),
        lon: lon.toString(),
        format: 'json',
        addressdetails: '1',
      });

      const response = await this.rateLimitedRequest(url);
      
      if (!response.ok) {
        throw new Error(`Reverse geocoding failed: ${response.status}`);
      }

      const result: NominatimResult = await response.json();
      
      return {
        lat,
        lon,
        name: result.display_name,
        address: result.display_name,
      };
    } catch (error) {
      console.error('Reverse geocoding error:', error);
      return null;
    }
  }

  async searchTouristAttractions(city: string, state: string = 'MG'): Promise<TouristAttraction[]> {
    try {
      // Search for tourist attractions using Nominatim
      const query = `tourism ${city} ${state} Brasil`;
      
      const url = `${this.NOMINATIM_BASE_URL}/search?` + new URLSearchParams({
        q: query,
        format: 'json',
        countrycodes: 'br',
        limit: '20',
        addressdetails: '1',
        extratags: '1',
        namedetails: '1',
      });

      const response = await this.rateLimitedRequest(url);
      
      if (!response.ok) {
        throw new Error(`Tourist search failed: ${response.status}`);
      }

      const results: NominatimResult[] = await response.json();
      
      return results
        .filter(result => this.isTouristAttraction(result))
        .map(result => this.convertToTouristAttraction(result))
        .slice(0, 10); // Limit to 10 results
        
    } catch (error) {
      console.error('Tourist attractions search error:', error);
      return [];
    }
  }

  private isTouristAttraction(result: NominatimResult): boolean {
    const touristClasses = [
      'tourism',
      'amenity',
      'historic',
      'leisure',
      'natural',
      'waterway'
    ];
    
    const touristTypes = [
      'attraction',
      'museum',
      'monument',
      'artwork',
      'viewpoint',
      'park',
      'zoo',
      'aquarium',
      'theme_park',
      'church',
      'cathedral',
      'castle',
      'ruins',
      'archaeological_site',
      'beach',
      'lake',
      'waterfall'
    ];

    return touristClasses.includes(result.class) || 
           touristTypes.includes(result.type) ||
           result.importance > 0.4; // High importance places
  }

  private convertToTouristAttraction(result: NominatimResult): TouristAttraction {
    const categories: Record<string, string> = {
      'tourism': 'Turismo',
      'historic': 'História',
      'natural': 'Natureza',
      'amenity': 'Serviços',
      'leisure': 'Lazer',
      'waterway': 'Águas'
    };

    return {
      id: `osm_${result.osm_type}_${result.osm_id}`,
      name: this.extractMainName(result.display_name),
      description: `Localizado em ${result.address?.city || result.address?.suburb || 'região'}, ${result.address?.state || 'MG'}`,
      category: categories[result.class] || 'Outros',
      lat: parseFloat(result.lat),
      lon: parseFloat(result.lon),
      address: result.display_name,
      city: result.address?.city || result.address?.suburb || 'N/A',
      state: result.address?.state || 'MG',
      rating: Math.min(5, Math.max(1, Math.round(result.importance * 5))),
    };
  }

  private extractMainName(displayName: string): string {
    // Extract the main name from the full display name
    const parts = displayName.split(',');
    return parts[0].trim();
  }

  generateMapUrl(lat: number, lon: number, zoom: number = 15): string {
    return `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}&zoom=${zoom}`;
  }

  generateDirectionsUrl(fromLat: number, fromLon: number, toLat: number, toLon: number): string {
    return `https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=${fromLat}%2C${fromLon}%3B${toLat}%2C${toLon}`;
  }

  async getCurrentLocation(): Promise<MapLocation | null> {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(null);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          const location = await this.reverseGeocode(latitude, longitude);
          resolve(location);
        },
        (error) => {
          console.error('Geolocation error:', error);
          resolve(null);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000, // 5 minutes
        }
      );
    });
  }

  // Fallback data for popular tourist attractions in BH Norte region
  getPopularAttractions(): TouristAttraction[] {
    return [
      {
        id: 'lagoa_central',
        name: 'Lagoa Central de Lagoa Santa',
        description: 'Lagoa natural famosa por suas águas cristalinas e sítios arqueológicos.',
        category: 'Natureza',
        lat: -19.6350,
        lon: -43.8920,
        address: 'Centro, Lagoa Santa, MG',
        city: 'Lagoa Santa',
        state: 'MG',
        rating: 4.5,
        opening_hours: '24 horas',
      },
      {
        id: 'gruta_rei_momo',
        name: 'Gruta do Rei do Mato',
        description: 'Sítio arqueológico onde foram encontrados os fósseis mais antigos das Américas.',
        category: 'História',
        lat: -19.6180,
        lon: -44.0420,
        address: 'Pedro Leopoldo, MG',
        city: 'Pedro Leopoldo',
        state: 'MG',
        rating: 4.8,
        opening_hours: 'Ter-Dom: 8h às 17h',
        contact: {
          phone: '(31) 3661-2851',
          website: 'https://museuarqueologico.com.br',
        },
      },
      {
        id: 'aeroporto_confins',
        name: 'Aeroporto Internacional Tancredo Neves',
        description: 'Principal aeroporto de Minas Gerais, ponto de conexão internacional.',
        category: 'Serviços',
        lat: -19.6320,
        lon: -43.9730,
        address: 'Confins, MG',
        city: 'Confins',
        state: 'MG',
        rating: 4.2,
        opening_hours: '24 horas',
        contact: {
          phone: '(31) 3689-2700',
          website: 'https://bh-airport.com.br',
        },
      },
      {
        id: 'centro_vespasiano',
        name: 'Centro Histórico de Vespasiano',
        description: 'Centro da cidade com arquitetura colonial e comércio local.',
        category: 'História',
        lat: -19.6920,
        lon: -44.0080,
        address: 'Centro, Vespasiano, MG',
        city: 'Vespasiano',
        state: 'MG',
        rating: 3.8,
        opening_hours: 'Seg-Sáb: 8h às 18h',
      },
      {
        id: 'parque_ecologico_vespasiano',
        name: 'Parque Ecológico de Vespasiano',
        description: 'Área verde com trilhas, lago e atividades ao ar livre.',
        category: 'Natureza',
        lat: -19.6850,
        lon: -44.0150,
        address: 'Vespasiano, MG',
        city: 'Vespasiano',
        state: 'MG',
        rating: 4.3,
        opening_hours: 'Todos os dias: 6h às 18h',
      },
    ];
  }
}

export const mapsService = new MapsService();
export type { TouristAttraction, MapLocation, NominatimResult };