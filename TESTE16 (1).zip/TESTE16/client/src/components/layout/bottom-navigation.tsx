import { useLocation } from "wouter";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Home, Route, Map, Settings, Building2, Camera, Music } from "lucide-react";

const navigationItems = [
  { path: "/", icon: Home, label: "Início" },
  { path: "/lines", icon: Route, label: "Linhas" },
  { path: "/tourism", icon: Camera, label: "Turismo" },
  { path: "/events", icon: Music, label: "Eventos" },
  { path: "/settings", icon: Settings, label: "Config" },
];

export function BottomNavigation() {
  const [location] = useLocation();

  return (
    <nav className="glass-effect border-t border-border material-elevation-2 sticky bottom-0 z-50 bg-background/95 backdrop-blur-sm">
      <div className="grid grid-cols-5 h-16 safe-area-pb">
        {navigationItems.map(({ path, icon: Icon, label }) => (
          <Link
            key={path}
            href={path}
            className={cn(
              "flex flex-col items-center justify-center space-y-1 touch-target transition-all duration-200 ease-out",
              "active:scale-95 active:bg-primary/10 rounded-lg mx-1 my-1",
              "focus:outline-none focus:ring-2 focus:ring-primary/20",
              location === path
                ? "text-primary bg-primary/5"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
            )}
            data-testid={`nav-${label.toLowerCase()}`}
          >
            <Icon className="w-5 h-5 transition-transform duration-200" />
            <span className="text-xs font-medium">{label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
}
