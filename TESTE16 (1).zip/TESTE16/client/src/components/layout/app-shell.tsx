import { BottomNavigation } from "./bottom-navigation";
import { FloatingActionButton } from "../ui/floating-action-button";
import { useState } from "react";

interface AppShellProps {
  children: React.ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const [showSearch, setShowSearch] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background relative">
      {/* Main Content */}
      <main className="flex-1 overflow-y-auto overscroll-y-contain p-4 pb-20" style={{
        WebkitOverflowScrolling: 'touch',
        scrollBehavior: 'smooth'
      }}>
        {children}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
      
      {/* Floating Action Button */}
      <FloatingActionButton 
        onClick={() => setShowSearch(!showSearch)}
        data-testid="fab-quick-search"
      />
    </div>
  );
}
