import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScheduleModal } from "./schedule-modal";
import { useFavorites } from "@/hooks/use-favorites";
import type { BusLine } from "@shared/schema";
import { Star, ChevronRight, Clock } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface LineCardProps {
  line: BusLine;
}

export function LineCard({ line }: LineCardProps) {
  const [showSchedule, setShowSchedule] = useState(false);
  const { isFavorite, toggleFavorite } = useFavorites();

  const getColorClass = (color: string) => {
    switch (color) {
      case "primary":
        return "bg-primary/10 text-primary";
      case "secondary":
        return "bg-secondary/10 text-secondary";
      case "accent":
        return "bg-accent/10 text-accent";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  // Calculate next departure (simplified for demo)
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const nextDeparture = Math.ceil(currentMinutes / 15) * 15;
  const nextTime = `${Math.floor(nextDeparture / 60).toString().padStart(2, '0')}:${(nextDeparture % 60).toString().padStart(2, '0')}`;

  return (
    <>
      <Card className="material-elevation-1 animate-fade-in">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 flex-1">
              <div className={cn(
                "w-12 h-12 rounded-lg flex items-center justify-center",
                getColorClass(line.color || "primary")
              )}>
                <span className="font-bold text-sm" data-testid={`line-number-${line.number}`}>
                  {line.number}
                </span>
              </div>
              
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground truncate" data-testid={`line-name-${line.id}`}>
                  {line.name}
                </h3>
                <p className="text-sm text-muted-foreground truncate">
                  {line.route}
                </p>
                <div className="flex items-center space-x-4 mt-1">
                  <span className="text-xs text-secondary font-medium flex items-center">
                    <Clock className="w-3 h-3 mr-1" />
                    Próximo: {nextTime}
                  </span>
                  <Badge variant="outline" className="text-xs">
                    {line.frequency}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col items-center space-y-2">
              <Button
                variant="ghost"
                size="icon"
                className="w-8 h-8 rounded-full bg-muted hover:bg-muted/80 touch-target"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFavorite(line.id);
                }}
                data-testid={`button-favorite-${line.id}`}
              >
                <Star className={cn(
                  "w-4 h-4 transition-colors",
                  isFavorite(line.id) 
                    ? "text-accent fill-accent" 
                    : "text-muted-foreground"
                )} />
              </Button>
              
              <Button
                size="icon"
                className="w-8 h-8 rounded-full touch-target"
                onClick={() => setShowSchedule(true)}
                data-testid={`button-schedule-${line.id}`}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <ScheduleModal
        isOpen={showSchedule}
        onClose={() => setShowSchedule(false)}
        lineId={line.id}
        lineName={`Linha ${line.number}`}
        lineNumber={line.number}
      />
    </>
  );
}
