import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "@/contexts/LocationContext";
import { Calendar, Clock, MapPin, ExternalLink, Music, Users, Star, Search, Filter, Ticket, Share2 } from "lucide-react";
import { Link } from "wouter";

interface Event {
  id: string;
  title: string;
  description?: string;
  artist?: string;
  venue: {
    name: string;
    address: string;
    city: string;
    region?: string;
    country: string;
    latitude?: number;
    longitude?: number;
  };
  datetime: string;
  date: string;
  time?: string;
  category: string;
  genre?: string;
  url?: string;
  ticketUrl?: string;
  imageUrl?: string;
  priceRange?: {
    min?: number;
    max?: number;
    currency: string;
  };
  source: 'bandsintown' | 'ticketmaster';
  sourceId: string;
  popularity?: number;
  availability?: 'available' | 'soldout' | 'cancelled';
}

interface EventCategory {
  id: string;
  name: string;
  icon: string;
}

export default function Events() {
  const [selectedCity, setSelectedCity] = useState("Belo Horizonte");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const { toast } = useToast();
  const { selectedCity: locationCity } = useLocation();

  // Update city when location context changes
  useEffect(() => {
    if (locationCity?.name) {
      setSelectedCity(locationCity.name);
    }
  }, [locationCity]);

  // Get event categories
  const { data: categoriesData } = useQuery({
    queryKey: ["/api/events/categories"],
    queryFn: async () => {
      const response = await fetch("/api/events/categories");
      const result = await response.json();
      return result.data as EventCategory[];
    }
  });

  // Get events based on filters
  const { data: eventsData, isLoading, refetch } = useQuery({
    queryKey: ["/api/events", selectedCity, selectedCategory, searchQuery],
    queryFn: async () => {
      let url = "/api/events";
      const params = new URLSearchParams();
      
      if (selectedCity) params.append("city", selectedCity);
      if (selectedCategory) params.append("category", selectedCategory);
      if (searchQuery) params.append("artist", searchQuery);
      params.append("limit", "25");
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const response = await fetch(url);
      const result = await response.json();
      return result.data;
    },
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
  });

  // Get popular events
  const { data: popularEventsData } = useQuery({
    queryKey: ["/api/events/popular", selectedCity],
    queryFn: async () => {
      const response = await fetch(`/api/events/popular?city=${encodeURIComponent(selectedCity)}`);
      const result = await response.json();
      return result.data;
    }
  });

  const events = eventsData?.events || [];
  const popularEvents = popularEventsData?.events || [];

  const cities = [
    "Belo Horizonte",
    "São José da Lapa", 
    "Vespasiano",
    "Ribeirão das Neves",
    "Santa Luzia",
    "Contagem"
  ];

  const handleSearch = () => {
    refetch();
    toast({
      title: "Buscando eventos",
      description: `Procurando eventos ${searchQuery ? `de "${searchQuery}"` : ''} em ${selectedCity}`,
    });
  };

  const handleShare = async (event: Event) => {
    const shareText = `🎵 ${event.title}\n📅 ${event.date}${event.time ? ` às ${event.time}` : ''}\n📍 ${event.venue.name}\n\nVia LapaBus Events`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: event.title,
          text: shareText,
          url: event.url || window.location.href,
        });
      } catch (error) {
        // User cancelled share
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareText);
        toast({
          title: "Evento copiado",
          description: "Informações do evento copiadas para área de transferência",
        });
      } catch (error) {
        toast({
          title: "Erro",
          description: "Não foi possível copiar as informações",
          variant: "destructive",
        });
      }
    }
  };

  const getSourceBadge = (source: string) => {
    const badges: Record<string, { label: string; color: string }> = {
      bandsintown: { label: "Bandsintown", color: "bg-green-500" },
      ticketmaster: { label: "Ticketmaster", color: "bg-blue-500" }
    };
    
    const badge = badges[source] || { label: source, color: "bg-gray-500" };
    
    return (
      <Badge className={`${badge.color} text-white text-xs`}>
        {badge.label}
      </Badge>
    );
  };

  const getAvailabilityBadge = (availability: string) => {
    const badges: Record<string, { label: string; color: string }> = {
      available: { label: "Disponível", color: "bg-green-100 text-green-800" },
      soldout: { label: "Esgotado", color: "bg-red-100 text-red-800" },
      cancelled: { label: "Cancelado", color: "bg-gray-100 text-gray-800" }
    };
    
    const badge = badges[availability] || badges.available;
    
    return (
      <Badge className={badge.color}>
        {badge.label}
      </Badge>
    );
  };

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Music className="text-indigo-600" />
                Eventos & Shows
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                Descubra shows e eventos na região
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2"
            >
              <Filter className="w-4 h-4" />
              Filtros
            </Button>
          </div>
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="bg-white border-b shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Buscar Artista</label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Nome do artista..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  />
                  <Button onClick={handleSearch} size="sm">
                    <Search className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Cidade</label>
                <Select value={selectedCity} onValueChange={setSelectedCity}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map((city) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Categoria</label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todas as categorias" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Todas as categorias</SelectItem>
                    {categoriesData?.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.icon} {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button onClick={handleSearch} className="w-full">
                  <Search className="w-4 h-4 mr-2" />
                  Buscar Eventos
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 max-w-7xl mx-auto w-full px-4 py-6">
        {/* Popular Events Section */}
        {popularEvents.length > 0 && !searchQuery && !selectedCategory && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Star className="text-yellow-500" />
              Eventos Populares em {selectedCity}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {popularEvents.slice(0, 6).map((event) => (
                <EventCard key={event.id} event={event} onShare={handleShare} />
              ))}
            </div>
          </div>
        )}

        {/* Main Events Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              <Calendar className="text-indigo-600" />
              {searchQuery ? `Resultados para "${searchQuery}"` : 'Todos os Eventos'}
              {events.length > 0 && (
                <Badge variant="secondary">{events.length}</Badge>
              )}
            </h2>
            {eventsData?.sources && (
              <div className="flex gap-2">
                {eventsData.sources.map((source) => getSourceBadge(source))}
              </div>
            )}
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="h-3 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : events.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {events.map((event) => (
                <EventCard key={event.id} event={event} onShare={handleShare} />
              ))}
            </div>
          ) : (
            <Card className="text-center py-12">
              <CardContent>
                <Music className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Nenhum evento encontrado
                </h3>
                <p className="text-gray-600 mb-4">
                  Não encontramos eventos para os filtros selecionados.
                </p>
                <Button onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("");
                  refetch();
                }}>
                  Limpar Filtros
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function EventCard({ event, onShare }: { event: Event; onShare: (event: Event) => void }) {
  const eventDate = new Date(event.datetime);
  const isUpcoming = eventDate > new Date();
  
  return (
    <Card className="group hover:shadow-lg transition-all duration-300 border-0 shadow-md overflow-hidden">
      {event.imageUrl && (
        <div className="relative h-48 overflow-hidden">
          <img
            src={event.imageUrl}
            alt={event.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-3 right-3 flex gap-2">
            {event.source && (
              <Badge className="bg-black/70 text-white text-xs">
                {event.source === 'bandsintown' ? 'Bandsintown' : 'Ticketmaster'}
              </Badge>
            )}
          </div>
        </div>
      )}
      
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-lg font-semibold line-clamp-2 group-hover:text-indigo-600 transition-colors">
            {event.title}
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onShare(event);
            }}
            className="opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
        
        {event.artist && (
          <p className="text-sm text-gray-600 flex items-center gap-1">
            <Users className="w-4 h-4" />
            {event.artist}
          </p>
        )}
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Calendar className="w-4 h-4 text-indigo-500" />
          <span>{event.date}</span>
          {event.time && (
            <>
              <Clock className="w-4 h-4 text-indigo-500 ml-2" />
              <span>{event.time}</span>
            </>
          )}
        </div>

        <div className="flex items-start gap-2 text-sm text-gray-600">
          <MapPin className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
          <div>
            <div className="font-medium">{event.venue.name}</div>
            <div className="text-xs">{event.venue.address}</div>
          </div>
        </div>

        {event.genre && (
          <div className="flex flex-wrap gap-1">
            <Badge variant="secondary" className="text-xs">
              {event.genre}
            </Badge>
            {event.category && event.category !== event.genre && (
              <Badge variant="outline" className="text-xs">
                {event.category}
              </Badge>
            )}
          </div>
        )}

        {event.priceRange && (
          <div className="text-sm text-green-600 font-medium">
            {event.priceRange.min && event.priceRange.max 
              ? `${event.priceRange.currency} ${event.priceRange.min} - ${event.priceRange.max}`
              : event.priceRange.min 
                ? `A partir de ${event.priceRange.currency} ${event.priceRange.min}`
                : `Até ${event.priceRange.currency} ${event.priceRange.max}`
            }
          </div>
        )}

        {event.availability && (
          <div className="flex items-center justify-between">
            {event.availability === 'available' ? (
              <Badge className="bg-green-100 text-green-800">
                Disponível
              </Badge>
            ) : event.availability === 'soldout' ? (
              <Badge className="bg-red-100 text-red-800">
                Esgotado
              </Badge>
            ) : (
              <Badge className="bg-gray-100 text-gray-800">
                Cancelado
              </Badge>
            )}
          </div>
        )}

        <div className="flex gap-2 pt-2">
          {event.ticketUrl && (
            <Button asChild size="sm" className="flex-1">
              <a href={event.ticketUrl} target="_blank" rel="noopener noreferrer">
                <Ticket className="w-4 h-4 mr-2" />
                Ingressos
              </a>
            </Button>
          )}
          
          {event.venue.latitude && event.venue.longitude && (
            <Button asChild variant="outline" size="sm">
              <a 
                href={`https://www.openstreetmap.org/?mlat=${event.venue.latitude}&mlon=${event.venue.longitude}&zoom=17&layers=M`}
                target="_blank" 
                rel="noopener noreferrer"
              >
                <MapPin className="w-4 h-4" />
              </a>
            </Button>
          )}
          
          {event.url && (
            <Button asChild variant="outline" size="sm">
              <a href={event.url} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="w-4 h-4" />
              </a>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}