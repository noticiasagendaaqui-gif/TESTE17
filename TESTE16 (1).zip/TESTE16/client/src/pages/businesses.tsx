import { useQuery } from "@tanstack/react-query";
import { useRoute, useSearch } from "wouter";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Building2, Phone, MessageCircle, MapPin, Star, ExternalLink, Bus, UtensilsCrossed, Bed, Heart, Wrench, ShoppingBag, GraduationCap, Camera } from "lucide-react";

interface Business {
  id: string;
  name: string;
  slug: string;
  category: string;
  subcategory: string | null;
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  neighborhood: string | null;
  description: string | null;
  services: string[] | null;
  priceRange: string | null;
  rating: number | null;
  reviewCount: number | null;
  isVerified: boolean;
  isActive: boolean;
  cityId: string;
}

interface BusinessCategory {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
  description: string;
  isActive: boolean;
}

export default function BusinessesPage() {
  const [match, params] = useRoute("/businesses/:category?");
  const search = useSearch();
  const searchParams = new URLSearchParams(search);
  const categoryParam = params?.category || searchParams.get('category');
  const cityParam = searchParams.get('city');

  const { data: businesses = [], isLoading: businessesLoading } = useQuery({
    queryKey: ["/api/businesses", categoryParam, cityParam],
    queryFn: async () => {
      let url = "/api/businesses";
      const params = new URLSearchParams();
      
      if (categoryParam) params.append('category', categoryParam);
      if (cityParam) params.append('city', cityParam);
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const response = await fetch(url);
      const result = await response.json();
      return result.data as Business[];
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      const result = await response.json();
      return result.data as BusinessCategory[];
    },
  });

  const { data: cities = [] } = useQuery({
    queryKey: ["/api/cities"],
    queryFn: async () => {
      const response = await fetch("/api/cities");
      const result = await response.json();
      return result.data;
    },
  });

  // Icon mapping for categories
  const getCategoryIcon = (slug: string) => {
    const iconMap: { [key: string]: React.ComponentType<any> } = {
      transport: Bus,
      restaurants: UtensilsCrossed,
      hotels: Bed,
      health: Heart,
      services: Wrench,
      retail: ShoppingBag,
      education: GraduationCap,
      leisure: Camera,
    };
    return iconMap[slug] || Building2;
  };

  const handleWhatsAppClick = (whatsapp: string, businessName: string) => {
    const message = `Olá! Gostaria de mais informações sobre os serviços da ${businessName}.`;
    const url = `https://wa.me/${whatsapp}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
  };

  const handlePhoneClick = (phone: string) => {
    window.open(`tel:${phone}`, "_self");
  };

  const currentCategory = categories.find(cat => cat.slug === categoryParam);
  const currentCity = cities.find((city: any) => city.id === cityParam);

  const renderStars = (rating: number | null) => {
    if (!rating) return null;
    return (
      <div className="flex items-center space-x-1">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            className={`w-4 h-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
          />
        ))}
        <span className="text-sm text-gray-600 ml-1">({rating})</span>
      </div>
    );
  };

  if (businessesLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <Link href="/">
          <Button variant="ghost" size="sm" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar ao início
          </Button>
        </Link>
        
        <div className="flex items-center mb-4">
          {currentCategory && (
            <div className="flex items-center mr-4">
              {(() => {
                const IconComponent = getCategoryIcon(currentCategory.slug);
                return <IconComponent className={`w-8 h-8 text-${currentCategory.color}-600 mr-3`} />;
              })()}
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  {currentCategory.name}
                </h1>
                <p className="text-gray-600">
                  {currentCategory.description}
                </p>
              </div>
            </div>
          )}
        </div>
        
        {currentCity && (
          <Badge variant="secondary" className="mb-4">
            <MapPin className="w-4 h-4 mr-1" />
            {currentCity.name}
          </Badge>
        )}
        
        <p className="text-gray-600">
          {businesses.length} empresa{businesses.length !== 1 ? 's' : ''} encontrada{businesses.length !== 1 ? 's' : ''} 
          {currentCategory && ` na categoria ${currentCategory.name.toLowerCase()}`}
          {currentCity && ` em ${currentCity.name}`}
        </p>
      </div>

      {/* Businesses Grid */}
      {businesses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {businesses.map((business) => {
            const businessCity = cities.find((city: any) => city.id === business.cityId);
            
            return (
              <Card key={business.id} className="cursor-pointer transition-all duration-300 ease-out hover:shadow-lg active:scale-[0.98] bg-gradient-to-br from-white to-gray-50 border border-gray-200 touch-target">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-xl text-gray-900 flex items-center gap-2">
                        <Building2 className="h-5 w-5 text-primary" />
                        {business.name}
                        {business.isVerified && (
                          <Badge variant="secondary" className="text-xs">
                            Verificado
                          </Badge>
                        )}
                      </CardTitle>
                      
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {business.category}
                        </Badge>
                        {businessCity && (
                          <Badge variant="outline" className="text-xs">
                            <MapPin className="w-3 h-3 mr-1" />
                            {businessCity.name}
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    {business.priceRange && (
                      <Badge variant="secondary" className="text-lg font-bold">
                        {business.priceRange}
                      </Badge>
                    )}
                  </div>
                  
                  <CardDescription className="text-gray-600">
                    {business.description}
                  </CardDescription>
                </CardHeader>

                <CardContent>
                  <div className="space-y-4">
                    {/* Address */}
                    {business.address && (
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="h-4 w-4 mr-2 flex-shrink-0" />
                        <span>{business.address}, {business.neighborhood}</span>
                      </div>
                    )}

                    {/* Services */}
                    {business.services && business.services.length > 0 && (
                      <div>
                        <div className="flex flex-wrap gap-1">
                          {business.services.slice(0, 3).map((service) => (
                            <Badge key={service} variant="outline" className="text-xs">
                              {service}
                            </Badge>
                          ))}
                          {business.services.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{business.services.length - 3} mais
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Rating */}
                    {business.rating && business.reviewCount && (
                      <div className="flex items-center justify-between">
                        {renderStars(business.rating)}
                        <span className="text-sm text-gray-500">
                          {business.reviewCount} avaliações
                        </span>
                      </div>
                    )}

                    {/* Contact Buttons */}
                    <div className="flex gap-2 pt-3 border-t border-gray-100">
                      {business.phone && (
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => handlePhoneClick(business.phone!)}
                        >
                          <Phone className="w-4 h-4 mr-1" />
                          Ligar
                        </Button>
                      )}
                      
                      {business.whatsapp && (
                        <Button 
                          size="sm" 
                          className="flex-1 bg-green-600 hover:bg-green-700"
                          onClick={() => handleWhatsAppClick(business.whatsapp!, business.name)}
                        >
                          <MessageCircle className="w-4 h-4 mr-1" />
                          WhatsApp
                        </Button>
                      )}
                      
                      {business.website && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => window.open(business.website, "_blank")}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12">
          <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhuma empresa encontrada
          </h3>
          <p className="text-gray-600 mb-4">
            Não há empresas cadastradas 
            {currentCategory && ` na categoria ${currentCategory.name.toLowerCase()}`}
            {currentCity && ` em ${currentCity.name}`}.
          </p>
          <Link href="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar ao início
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}