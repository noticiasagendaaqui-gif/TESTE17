import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Settings, 
  Users, 
  Building2, 
  Bus, 
  BarChart3, 
  LogOut,
  Save,
  Plus,
  Trash2,
  Edit,
  Eye,
  Search,
  Download,
  Upload,
  MapPin,
  Globe,
  FileText,
  Camera,
  Star,
  Clock,
  Heart,
  Map,
  Mountain,
  TreePine,
  Compass
} from "lucide-react";
import type { Settings as SettingsType, User } from "@shared/auth-schema";

export default function AdminPage() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [settings, setSettings] = useState<SettingsType[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingSettings, setEditingSettings] = useState<{ [key: string]: string }>({});
  
  // Estados para gestão de empresas
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [cities, setCities] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedCity, setSelectedCity] = useState("");
  const [searchCity, setSearchCity] = useState("");
  const [cnpjSearch, setCnpjSearch] = useState("");
  const [cepSearch, setCepSearch] = useState("");

  // Estados para gestão de turismo
  const [tourismResults, setTourismResults] = useState<any[]>([]);
  const [tourismSearchCity, setTourismSearchCity] = useState("");
  const [selectedTourismCity, setSelectedTourismCity] = useState("");
  const [tourismApiStatus, setTourismApiStatus] = useState<any>({});
  const [isTourismSearching, setIsTourismSearching] = useState(false);
  const [tourismSearchRadius, setTourismSearchRadius] = useState("5000");
  const [selectedApiSource, setSelectedApiSource] = useState("all");

  // Redirect if not authenticated or not admin
  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
            <CardDescription>
              Você não tem permissão para acessar o painel administrativo.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => logout()} className="w-full">
              Fazer Logout
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  useEffect(() => {
    fetchData();
    fetchCities();
    fetchTourismApiStatus();
  }, []);

  const fetchData = async () => {
    try {
      setIsLoading(true);
      
      // Fetch settings
      const settingsResponse = await fetch('/api/auth/settings');
      if (settingsResponse.ok) {
        const settingsResult = await settingsResponse.json();
        setSettings(settingsResult.data);
        
        // Initialize editing state
        const editingState: { [key: string]: string } = {};
        settingsResult.data.forEach((setting: SettingsType) => {
          editingState[setting.key] = setting.value;
        });
        setEditingSettings(editingState);
      }

      // Fetch users
      const usersResponse = await fetch('/api/auth/users');
      if (usersResponse.ok) {
        const usersResult = await usersResponse.json();
        setUsers(usersResult.data);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSettingUpdate = async (key: string, value: string) => {
    try {
      const response = await fetch(`/api/auth/settings/${key}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ value }),
      });

      if (response.ok) {
        await fetchData(); // Refresh data
      }
    } catch (error) {
      console.error('Erro ao atualizar configuração:', error);
    }
  };

  const handleLogout = async () => {
    await logout();
  };

  // Funções para gestão de empresas
  const fetchCities = async () => {
    try {
      const response = await fetch('/api/cities');
      if (response.ok) {
        const result = await response.json();
        setCities(result.data);
      }
    } catch (error) {
      console.error('Erro ao carregar cidades:', error);
    }
  };

  const searchBusinessesByCity = async () => {
    if (!searchCity.trim()) return;
    
    setIsSearching(true);
    try {
      const response = await fetch('/api/auth/external/search-businesses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cityName: searchCity, state: 'MG' })
      });
      
      if (response.ok) {
        const result = await response.json();
        setSearchResults(result.data.businesses);
      }
    } catch (error) {
      console.error('Erro na busca:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const searchByCNPJ = async () => {
    if (!cnpjSearch.trim()) return;
    
    setIsSearching(true);
    try {
      const response = await fetch('/api/auth/external/search-cnpj', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cnpj: cnpjSearch })
      });
      
      if (response.ok) {
        const result = await response.json();
        setSearchResults([result.data]);
      }
    } catch (error) {
      console.error('Erro na busca por CNPJ:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const autoPopulateCity = async (cityId: string) => {
    setIsSearching(true);
    try {
      const response = await fetch('/api/auth/external/auto-populate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cityId, limit: 20 })
      });
      
      if (response.ok) {
        const result = await response.json();
        alert(`${result.data.imported} empresas foram adicionadas em ${result.data.city}!`);
      }
    } catch (error) {
      console.error('Erro na auto-população:', error);
      alert('Erro ao popular empresas automaticamente');
    } finally {
      setIsSearching(false);
    }
  };

  const importBusinesses = async (businesses: any[]) => {
    if (!selectedCity || businesses.length === 0) return;
    
    setIsSearching(true);
    try {
      const response = await fetch('/api/auth/external/import-businesses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ businesses, cityId: selectedCity })
      });
      
      if (response.ok) {
        const result = await response.json();
        alert(`${result.data.imported} empresas importadas com sucesso!`);
        setSearchResults([]);
      }
    } catch (error) {
      console.error('Erro na importação:', error);
      alert('Erro ao importar empresas');
    } finally {
      setIsSearching(false);
    }
  };

  // Funções para gestão de turismo
  const fetchTourismApiStatus = async () => {
    try {
      const response = await fetch('/api/auth/tourism/api-status');
      if (response.ok) {
        const result = await response.json();
        setTourismApiStatus(result.data);
      }
    } catch (error) {
      console.error('Erro ao carregar status das APIs de turismo:', error);
    }
  };

  const searchTourismAttractions = async () => {
    if (!tourismSearchCity.trim()) return;
    
    setIsTourismSearching(true);
    try {
      let endpoint = '/api/auth/tourism/search-attractions';
      
      // Escolher endpoint baseado na API selecionada
      if (selectedApiSource === 'osm') endpoint = '/api/auth/tourism/search-osm';
      else if (selectedApiSource === 'amadeus') endpoint = '/api/auth/tourism/search-amadeus';
      else if (selectedApiSource === 'geoapify') endpoint = '/api/auth/tourism/search-geoapify';
      else if (selectedApiSource === 'tripadvisor') endpoint = '/api/auth/tourism/search-tripadvisor';
      else if (selectedApiSource === 'locationiq') endpoint = '/api/auth/tourism/search-locationiq';

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          cityName: tourismSearchCity,
          radius: parseInt(tourismSearchRadius),
          limit: 20
        })
      });
      
      if (response.ok) {
        const result = await response.json();
        setTourismResults(result.data.attractions);
      }
    } catch (error) {
      console.error('Erro na busca de atrações:', error);
    } finally {
      setIsTourismSearching(false);
    }
  };

  const autoPopulateTourism = async (cityId: string) => {
    setIsTourismSearching(true);
    try {
      const response = await fetch('/api/auth/tourism/auto-populate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          cityId, 
          limit: 30,
          useOnlyFree: selectedApiSource === 'osm' || selectedApiSource === 'all'
        })
      });
      
      if (response.ok) {
        const result = await response.json();
        alert(`${result.data.imported} atrações turísticas foram adicionadas em ${result.data.city}!`);
      }
    } catch (error) {
      console.error('Erro na auto-população de turismo:', error);
      alert('Erro ao popular atrações automaticamente');
    } finally {
      setIsTourismSearching(false);
    }
  };

  const importTourismAttractions = async (attractions: any[]) => {
    if (!selectedTourismCity || attractions.length === 0) return;
    
    setIsTourismSearching(true);
    try {
      const response = await fetch('/api/auth/tourism/import-attractions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ attractions, cityId: selectedTourismCity })
      });
      
      if (response.ok) {
        const result = await response.json();
        alert(`${result.data.imported} atrações turísticas importadas com sucesso!`);
        setTourismResults([]);
      }
    } catch (error) {
      console.error('Erro na importação de atrações:', error);
      alert('Erro ao importar atrações turísticas');
    } finally {
      setIsTourismSearching(false);
    }
  };

  const getSettingsByCategory = (category: string) => {
    return settings.filter(setting => setting.category === category);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Bus className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                  LapaBus Admin
                </h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Painel Administrativo
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900 dark:text-white">
                  {user?.username}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {user?.role === 'admin' ? 'Administrador' : 'Usuário'}
                </p>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleLogout}
                className="flex items-center gap-2"
              >
                <LogOut className="h-4 w-4" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="businesses" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Empresas
            </TabsTrigger>
            <TabsTrigger value="tourism" className="flex items-center gap-2">
              <Mountain className="h-4 w-4" />
              Turismo
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Configurações
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Usuários
            </TabsTrigger>
            <TabsTrigger value="system" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Sistema
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{users.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Configurações</CardTitle>
                  <Settings className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{settings.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sistema</CardTitle>
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">Online</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Status</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">Ativo</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Visão Geral do Sistema</CardTitle>
                <CardDescription>
                  Status atual do LapaBus e informações importantes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div>
                      <h3 className="font-medium text-blue-900 dark:text-blue-100">
                        Sistema Operacional
                      </h3>
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        Todos os serviços estão funcionando normalmente
                      </p>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Online
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="businesses" className="mt-6">
            <div className="space-y-6">
              {/* Busca por Cidade */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5" />
                    Buscar Empresas por Cidade
                  </CardTitle>
                  <CardDescription>
                    Busque empresas em uma cidade usando APIs externas (OpenStreetMap)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <Label htmlFor="searchCity">Nome da Cidade</Label>
                      <Input
                        id="searchCity"
                        placeholder="Ex: São José da Lapa"
                        value={searchCity}
                        onChange={(e) => setSearchCity(e.target.value)}
                      />
                    </div>
                    <div className="flex items-end">
                      <Button 
                        onClick={searchBusinessesByCity}
                        disabled={isSearching || !searchCity.trim()}
                        className="flex items-center gap-2"
                      >
                        {isSearching ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <Search className="h-4 w-4" />
                        )}
                        Buscar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Busca por CNPJ */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Buscar por CNPJ
                  </CardTitle>
                  <CardDescription>
                    Consulte dados de uma empresa específica usando CNPJ (BrasilAPI)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <Label htmlFor="cnpjSearch">CNPJ</Label>
                      <Input
                        id="cnpjSearch"
                        placeholder="00.000.000/0000-00"
                        value={cnpjSearch}
                        onChange={(e) => setCnpjSearch(e.target.value)}
                      />
                    </div>
                    <div className="flex items-end">
                      <Button 
                        onClick={searchByCNPJ}
                        disabled={isSearching || !cnpjSearch.trim()}
                        className="flex items-center gap-2"
                      >
                        {isSearching ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <FileText className="h-4 w-4" />
                        )}
                        Consultar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Auto-Popular Cidades */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="h-5 w-5" />
                    Auto-Popular Empresas
                  </CardTitle>
                  <CardDescription>
                    Busque e importe automaticamente empresas para uma cidade
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {cities.map((city) => (
                      <div key={city.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-medium">{city.name}</h3>
                          <p className="text-sm text-gray-600">{city.population?.toLocaleString()} habitantes</p>
                        </div>
                        <Button
                          onClick={() => autoPopulateCity(city.id)}
                          disabled={isSearching}
                          size="sm"
                          className="flex items-center gap-2"
                        >
                          <Download className="h-4 w-4" />
                          Popular
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Resultados da Busca */}
              {searchResults.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Building2 className="h-5 w-5" />
                      Resultados da Busca ({searchResults.length})
                    </CardTitle>
                    <CardDescription>
                      Selecione as empresas que deseja importar para o sistema
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Seletor de Cidade */}
                    <div className="flex gap-4 items-end">
                      <div className="flex-1">
                        <Label htmlFor="selectedCity">Cidade de Destino</Label>
                        <select
                          id="selectedCity"
                          value={selectedCity}
                          onChange={(e) => setSelectedCity(e.target.value)}
                          className="w-full rounded-md border border-gray-300 px-3 py-2"
                        >
                          <option value="">Selecione uma cidade</option>
                          {cities.map((city) => (
                            <option key={city.id} value={city.id}>
                              {city.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => importBusinesses(searchResults)}
                          disabled={!selectedCity || isSearching}
                          className="flex items-center gap-2"
                        >
                          <Upload className="h-4 w-4" />
                          Importar Todos
                        </Button>
                        <Button
                          onClick={() => setSearchResults([])}
                          variant="outline"
                        >
                          Limpar
                        </Button>
                      </div>
                    </div>

                    {/* Lista de Empresas */}
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {searchResults.map((business, index) => (
                        <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex-1">
                            <h3 className="font-medium">{business.name}</h3>
                            <p className="text-sm text-gray-600">{business.address}</p>
                            <div className="flex gap-2 mt-1">
                              <Badge variant="secondary">{business.category}</Badge>
                              {business.subcategory && (
                                <Badge variant="outline">{business.subcategory}</Badge>
                              )}
                            </div>
                            {business.phone && (
                              <p className="text-sm text-gray-500 mt-1">📞 {business.phone}</p>
                            )}
                            {business.coordinates && (
                              <p className="text-sm text-gray-500">📍 {business.coordinates}</p>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              onClick={() => importBusinesses([business])}
                              disabled={!selectedCity || isSearching}
                              size="sm"
                              className="flex items-center gap-2"
                            >
                              <Plus className="h-4 w-4" />
                              Importar
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Estatísticas */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    APIs Disponíveis
                  </CardTitle>
                  <CardDescription>
                    Integrações com APIs externas para busca de empresas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Globe className="h-5 w-5 text-green-600" />
                        <h3 className="font-medium">OpenStreetMap</h3>
                      </div>
                      <p className="text-sm text-gray-600">Mapas e localização gratuitos</p>
                      <Badge variant="outline" className="mt-2 text-green-600">Ativo</Badge>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-5 w-5 text-blue-600" />
                        <h3 className="font-medium">BrasilAPI</h3>
                      </div>
                      <p className="text-sm text-gray-600">Consulta CNPJ e dados empresariais</p>
                      <Badge variant="outline" className="mt-2 text-blue-600">Ativo</Badge>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <MapPin className="h-5 w-5 text-purple-600" />
                        <h3 className="font-medium">ViaCEP</h3>
                      </div>
                      <p className="text-sm text-gray-600">Busca de endereços por CEP</p>
                      <Badge variant="outline" className="mt-2 text-purple-600">Ativo</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tourism" className="mt-6">
            <div className="space-y-6">
              {/* Seletor de API */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Compass className="h-5 w-5" />
                    Fonte de Dados de Turismo
                  </CardTitle>
                  <CardDescription>
                    Escolha qual API usar para buscar atrações turísticas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="apiSource">API de Origem</Label>
                      <select
                        id="apiSource"
                        value={selectedApiSource}
                        onChange={(e) => setSelectedApiSource(e.target.value)}
                        className="w-full rounded-md border border-gray-300 px-3 py-2"
                      >
                        <option value="all">Todas as APIs (Recomendado)</option>
                        <option value="osm">OpenStreetMap (Gratuito)</option>
                        <option value="amadeus">Amadeus Points of Interest</option>
                        <option value="geoapify">Geoapify Places</option>
                        <option value="tripadvisor">TripAdvisor Content</option>
                        <option value="locationiq">LocationIQ</option>
                      </select>
                    </div>
                    <div>
                      <Label htmlFor="searchRadius">Raio de Busca (metros)</Label>
                      <Input
                        id="searchRadius"
                        type="number"
                        value={tourismSearchRadius}
                        onChange={(e) => setTourismSearchRadius(e.target.value)}
                        placeholder="5000"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Busca por Cidade - Turismo */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5" />
                    Buscar Atrações Turísticas
                  </CardTitle>
                  <CardDescription>
                    Encontre pontos turísticos, museus, parques e atrações em uma cidade
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <Label htmlFor="tourismSearchCity">Nome da Cidade</Label>
                      <Input
                        id="tourismSearchCity"
                        placeholder="Ex: São José da Lapa"
                        value={tourismSearchCity}
                        onChange={(e) => setTourismSearchCity(e.target.value)}
                      />
                    </div>
                    <div className="flex items-end">
                      <Button 
                        onClick={searchTourismAttractions}
                        disabled={isTourismSearching || !tourismSearchCity.trim()}
                        className="flex items-center gap-2"
                      >
                        {isTourismSearching ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <Mountain className="h-4 w-4" />
                        )}
                        Buscar Atrações
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Auto-Popular Turismo */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="h-5 w-5" />
                    Auto-Popular Atrações Turísticas
                  </CardTitle>
                  <CardDescription>
                    Importe automaticamente pontos turísticos para cada cidade
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {cities.map((city) => (
                      <div key={city.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-medium">{city.name}</h3>
                          <p className="text-sm text-gray-600">{city.population?.toLocaleString()} habitantes</p>
                          <div className="flex gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              <Mountain className="h-3 w-3 mr-1" />
                              Turismo
                            </Badge>
                          </div>
                        </div>
                        <Button
                          onClick={() => autoPopulateTourism(city.id)}
                          disabled={isTourismSearching}
                          size="sm"
                          className="flex items-center gap-2"
                        >
                          <TreePine className="h-4 w-4" />
                          Popular
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Resultados da Busca de Turismo */}
              {tourismResults.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Map className="h-5 w-5" />
                      Atrações Encontradas ({tourismResults.length})
                    </CardTitle>
                    <CardDescription>
                      Selecione as atrações turísticas que deseja importar
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Seletor de Cidade para Turismo */}
                    <div className="flex gap-4 items-end">
                      <div className="flex-1">
                        <Label htmlFor="selectedTourismCity">Cidade de Destino</Label>
                        <select
                          id="selectedTourismCity"
                          value={selectedTourismCity}
                          onChange={(e) => setSelectedTourismCity(e.target.value)}
                          className="w-full rounded-md border border-gray-300 px-3 py-2"
                        >
                          <option value="">Selecione uma cidade</option>
                          {cities.map((city) => (
                            <option key={city.id} value={city.id}>
                              {city.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => importTourismAttractions(tourismResults)}
                          disabled={!selectedTourismCity || isTourismSearching}
                          className="flex items-center gap-2"
                        >
                          <Upload className="h-4 w-4" />
                          Importar Todas
                        </Button>
                        <Button
                          onClick={() => setTourismResults([])}
                          variant="outline"
                        >
                          Limpar
                        </Button>
                      </div>
                    </div>

                    {/* Lista de Atrações Turísticas */}
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {tourismResults.map((attraction, index) => (
                        <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex-1">
                            <h3 className="font-medium">{attraction.name}</h3>
                            <p className="text-sm text-gray-600">{attraction.address}</p>
                            <div className="flex gap-2 mt-1">
                              <Badge variant="secondary">{attraction.category}</Badge>
                              {attraction.subcategory && (
                                <Badge variant="outline">{attraction.subcategory}</Badge>
                              )}
                              {attraction.verified && (
                                <Badge variant="outline" className="text-green-600">
                                  <Star className="h-3 w-3 mr-1" />
                                  Verificado
                                </Badge>
                              )}
                            </div>
                            {attraction.rating && (
                              <div className="flex items-center gap-1 mt-1">
                                <Star className="h-4 w-4 text-yellow-500 fill-current" />
                                <span className="text-sm">{attraction.rating}</span>
                                {attraction.reviewCount && (
                                  <span className="text-xs text-gray-500">({attraction.reviewCount} avaliações)</span>
                                )}
                              </div>
                            )}
                            {attraction.description && (
                              <p className="text-sm text-gray-500 mt-1">{attraction.description}</p>
                            )}
                            {attraction.openingHours && (
                              <p className="text-sm text-gray-500 mt-1">
                                <Clock className="h-3 w-3 inline mr-1" />
                                {attraction.openingHours}
                              </p>
                            )}
                            {attraction.website && (
                              <p className="text-sm text-blue-600 mt-1">
                                <Globe className="h-3 w-3 inline mr-1" />
                                <a href={attraction.website} target="_blank" rel="noopener noreferrer">
                                  {attraction.website}
                                </a>
                              </p>
                            )}
                            {attraction.photos && attraction.photos.length > 0 && (
                              <p className="text-sm text-gray-500 mt-1">
                                <Camera className="h-3 w-3 inline mr-1" />
                                {attraction.photos.length} foto(s) disponível(is)
                              </p>
                            )}
                            <div className="flex items-center gap-2 mt-2">
                              <Badge variant="outline" className="text-xs">
                                Fonte: {attraction.source?.toUpperCase()}
                              </Badge>
                              {attraction.coordinates && (
                                <Badge variant="outline" className="text-xs">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  {attraction.coordinates}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              onClick={() => importTourismAttractions([attraction])}
                              disabled={!selectedTourismCity || isTourismSearching}
                              size="sm"
                              className="flex items-center gap-2"
                            >
                              <Plus className="h-4 w-4" />
                              Importar
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Status das APIs de Turismo */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5" />
                    APIs de Turismo Disponíveis
                  </CardTitle>
                  <CardDescription>
                    Status das integrações com APIs externas para dados turísticos
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {tourismApiStatus.status && Object.entries(tourismApiStatus.status).map(([key, api]: [string, any]) => (
                      <div key={key} className="p-4 border rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          {key === 'osm' && <Globe className="h-5 w-5 text-green-600" />}
                          {key === 'amadeus' && <Compass className="h-5 w-5 text-blue-600" />}
                          {key === 'geoapify' && <MapPin className="h-5 w-5 text-purple-600" />}
                          {key === 'tripadvisor' && <Star className="h-5 w-5 text-orange-600" />}
                          {key === 'locationiq' && <Search className="h-5 w-5 text-teal-600" />}
                          {key === 'foursquare' && <Building2 className="h-5 w-5 text-red-600" />}
                          <h3 className="font-medium capitalize">
                            {key === 'osm' ? 'OpenStreetMap' : 
                             key === 'tripadvisor' ? 'TripAdvisor' : 
                             key === 'locationiq' ? 'LocationIQ' : 
                             key.charAt(0).toUpperCase() + key.slice(1)}
                          </h3>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{api.description}</p>
                        <div className="flex items-center justify-between">
                          <Badge 
                            variant={api.available ? "default" : "outline"} 
                            className={api.available ? "text-green-600" : "text-gray-600"}
                          >
                            {api.available ? "Ativo" : "Não Configurado"}
                          </Badge>
                          <span className="text-xs text-gray-500">{api.cost}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {tourismApiStatus.summary && (
                    <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium text-blue-900 dark:text-blue-100">
                            Resumo das APIs
                          </h3>
                          <p className="text-sm text-blue-700 dark:text-blue-300">
                            {tourismApiStatus.summary.available} de {tourismApiStatus.summary.total} APIs configuradas
                            {tourismApiStatus.summary.freeAvailable && " • OpenStreetMap (gratuito) sempre disponível"}
                          </p>
                        </div>
                        <Badge 
                          variant="secondary" 
                          className="bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100"
                        >
                          {Math.round((tourismApiStatus.summary.available / tourismApiStatus.summary.total) * 100)}% Ativo
                        </Badge>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <div className="space-y-6">
              {['general', 'auth', 'limits', 'system'].map((category) => {
                const categorySettings = getSettingsByCategory(category);
                if (categorySettings.length === 0) return null;

                const categoryNames: { [key: string]: string } = {
                  general: 'Configurações Gerais',
                  auth: 'Autenticação',
                  limits: 'Limites do Sistema',
                  system: 'Sistema'
                };

                return (
                  <Card key={category}>
                    <CardHeader>
                      <CardTitle>{categoryNames[category]}</CardTitle>
                      <CardDescription>
                        Configurações da categoria {categoryNames[category].toLowerCase()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {categorySettings.map((setting) => (
                        <div key={setting.key} className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-end">
                          <div className="lg:col-span-2">
                            <Label htmlFor={setting.key}>
                              {setting.description || setting.key}
                            </Label>
                            {setting.type === 'boolean' ? (
                              <select
                                id={setting.key}
                                value={editingSettings[setting.key] || setting.value}
                                onChange={(e) => setEditingSettings(prev => ({
                                  ...prev,
                                  [setting.key]: e.target.value
                                }))}
                                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                              >
                                <option value="true">Verdadeiro</option>
                                <option value="false">Falso</option>
                              </select>
                            ) : (
                              <Input
                                id={setting.key}
                                value={editingSettings[setting.key] || setting.value}
                                onChange={(e) => setEditingSettings(prev => ({
                                  ...prev,
                                  [setting.key]: e.target.value
                                }))}
                                className="mt-1"
                              />
                            )}
                          </div>
                          <Button
                            onClick={() => handleSettingUpdate(setting.key, editingSettings[setting.key])}
                            disabled={editingSettings[setting.key] === setting.value}
                            className="flex items-center gap-2"
                          >
                            <Save className="h-4 w-4" />
                            Salvar
                          </Button>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="users" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Usuários do Sistema</CardTitle>
                <CardDescription>
                  Gerencie usuários e suas permissões
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.map((userItem) => (
                    <div key={userItem.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <div className="flex items-center gap-3">
                          <h3 className="font-medium">{userItem.username}</h3>
                          <Badge variant={userItem.role === 'admin' ? 'default' : 'secondary'}>
                            {userItem.role === 'admin' ? 'Administrador' : 'Usuário'}
                          </Badge>
                          <Badge variant={userItem.isActive ? 'outline' : 'destructive'}>
                            {userItem.isActive ? 'Ativo' : 'Inativo'}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {userItem.email}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        {userItem.id !== user?.id && (
                          <Button variant="destructive" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Informações do Sistema</CardTitle>
                <CardDescription>
                  Detalhes técnicos e status do sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-medium">Estatísticas</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Versão:</span>
                        <span className="text-sm font-medium">1.0.0</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Status:</span>
                        <Badge variant="outline" className="text-green-600">Online</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Último Deploy:</span>
                        <span className="text-sm font-medium">Hoje</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="font-medium">Ações do Sistema</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <Eye className="h-4 w-4 mr-2" />
                        Ver Logs do Sistema
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Relatórios de Uso
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}