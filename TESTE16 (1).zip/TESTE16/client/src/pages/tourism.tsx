import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MapPin, 
  Search, 
  ExternalLink, 
  Navigation, 
  Phone,
  Globe,
  Star,
  Clock,
  Filter,
  Camera,
  Map,
  Heart,
  Share,
  Route
} from "lucide-react";

interface TourismAttraction {
  id: string;
  name: string;
  description?: string;
  category: string;
  subcategory?: string;
  address: string;
  coordinates?: string;
  latitude?: number;
  longitude?: number;
  phone?: string;
  website?: string;
  email?: string;
  rating?: number;
  reviewCount?: number;
  photos?: string[];
  tags?: string[];
  openingHours?: string;
  priceRange?: string;
  accessibility?: string[];
  source: string;
  sourceId: string;
  popularity?: number;
  verified?: boolean;
  lastUpdated: Date;
}

interface TourismCategory {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export default function TourismPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedCity, setSelectedCity] = useState("Belo Horizonte");

  // Fetch tourism categories
  const { data: categories = [] } = useQuery({
    queryKey: ["/api/tourism/categories"],
    queryFn: async () => {
      const response = await fetch("/api/tourism/categories");
      const result = await response.json();
      return result.data as TourismCategory[];
    },
  });

  // Fetch attractions
  const { data: attractionsData, isLoading, refetch } = useQuery({
    queryKey: ["/api/tourism/attractions", selectedCity, selectedCategory],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCity) params.append('city', selectedCity);
      if (selectedCategory !== 'all') params.append('category', selectedCategory);
      params.append('limit', '20');

      const response = await fetch(`/api/tourism/attractions?${params.toString()}`);
      const result = await response.json();
      return result.data;
    },
  });

  // Search attractions
  const { data: searchResults, isLoading: searchLoading } = useQuery({
    queryKey: ["/api/tourism/search", searchQuery, selectedCity],
    queryFn: async () => {
      if (!searchQuery.trim()) return null;
      
      const params = new URLSearchParams();
      params.append('q', searchQuery);
      params.append('city', selectedCity);
      params.append('limit', '15');

      const response = await fetch(`/api/tourism/search?${params.toString()}`);
      const result = await response.json();
      return result.data;
    },
    enabled: !!searchQuery.trim(),
  });

  const attractions = searchQuery.trim() ? searchResults?.attractions || [] : attractionsData?.attractions || [];
  const isSearchMode = !!searchQuery.trim();

  const handleSearch = () => {
    refetch();
  };

  const handleViewOnMap = (attraction: TourismAttraction) => {
    if (attraction.latitude && attraction.longitude) {
      const mapUrl = `https://www.openstreetmap.org/?mlat=${attraction.latitude}&mlon=${attraction.longitude}&zoom=16`;
      window.open(mapUrl, '_blank');
    }
  };

  const handleGetDirections = (attraction: TourismAttraction) => {
    if (attraction.latitude && attraction.longitude) {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            const directionsUrl = `https://www.openstreetmap.org/directions?engine=graphhopper_foot&route=${latitude}%2C${longitude}%3B${attraction.latitude}%2C${attraction.longitude}`;
            window.open(directionsUrl, '_blank');
          },
          () => {
            // Fallback to center of BH
            const directionsUrl = `https://www.openstreetmap.org/directions?engine=graphhopper_foot&route=-19.9191%2C-43.9387%3B${attraction.latitude}%2C${attraction.longitude}`;
            window.open(directionsUrl, '_blank');
          }
        );
      }
    }
  };

  const cities = [
    "Belo Horizonte",
    "São José da Lapa", 
    "Vespasiano",
    "Ribeirão das Neves",
    "Pedro Leopoldo",
    "Lagoa Santa"
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden bg-gradient-to-br from-green-500 via-blue-500 to-purple-600 p-6 rounded-2xl text-white material-elevation-2">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-1">Turismo BH Norte</h1>
              <p className="text-white/90 text-sm">Descubra atrações, pontos turísticos e lugares especiais</p>
            </div>
            <div className="text-right">
              <div className="flex items-center text-white/90 text-sm mb-1">
                <MapPin className="w-4 h-4 mr-1" />
                <span>{cities.length} cidades</span>
              </div>
              <div className="flex items-center text-white/90 text-sm">
                <Camera className="w-4 h-4 mr-1" />
                <span>{attractions.length}+ atrações</span>
              </div>
            </div>
          </div>
          
          {/* Search Bar */}
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-1">
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  placeholder="Buscar atrações, museus, parques..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-white/20 border-0 text-white placeholder:text-white/70"
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
              </div>
              <Button 
                onClick={handleSearch}
                className="bg-white/20 hover:bg-white/30 text-white border-0"
                size="icon"
              >
                <Search className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="space-y-4">
        {/* City Filter */}
        <div>
          <h3 className="text-sm font-medium text-foreground mb-2">Cidade</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {cities.map((city) => (
              <Button
                key={city}
                variant={selectedCity === city ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCity(city)}
                className="whitespace-nowrap"
              >
                {city}
              </Button>
            ))}
          </div>
        </div>

        {/* Category Filter */}
        <div>
          <h3 className="text-sm font-medium text-foreground mb-2">Categoria</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            <Button
              variant={selectedCategory === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("all")}
              className="whitespace-nowrap"
            >
              Todas
            </Button>
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className="whitespace-nowrap"
              >
                {category.icon} {category.name}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="space-y-4">
        {isSearchMode && (
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">
              {searchLoading ? "Buscando..." : `Resultados para "${searchQuery}"`}
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSearchQuery("")}
            >
              Limpar busca
            </Button>
          </div>
        )}

        {/* Loading State */}
        {(isLoading || searchLoading) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Attractions Grid */}
        {!isLoading && !searchLoading && attractions.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {attractions.map((attraction) => (
              <Card key={attraction.id} className="hover:shadow-lg transition-all duration-300 touch-target bg-gradient-to-br from-white to-gray-50 dark:from-gray-800 dark:to-gray-900">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg line-clamp-2 flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-primary flex-shrink-0" />
                        {attraction.name}
                      </CardTitle>
                      
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="secondary" className="text-xs">
                          {attraction.category}
                        </Badge>
                        {attraction.verified && (
                          <Badge variant="outline" className="text-xs">
                            Verificado
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    {attraction.rating && (
                      <div className="flex items-center gap-1 text-sm">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium">{attraction.rating.toFixed(1)}</span>
                      </div>
                    )}
                  </div>
                  
                  {attraction.description && (
                    <CardDescription className="line-clamp-2">
                      {attraction.description}
                    </CardDescription>
                  )}
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Address */}
                  <div className="flex items-center text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 mr-2 flex-shrink-0" />
                    <span className="line-clamp-1">{attraction.address}</span>
                  </div>

                  {/* Tags */}
                  {attraction.tags && attraction.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {attraction.tags.slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewOnMap(attraction)}
                      className="flex-1 min-w-0"
                    >
                      <Map className="w-4 h-4 mr-1" />
                      Ver no Mapa
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleGetDirections(attraction)}
                      className="flex-1 min-w-0"
                    >
                      <Route className="w-4 h-4 mr-1" />
                      Ir
                    </Button>

                    {attraction.website && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(attraction.website, "_blank")}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  {/* Source */}
                  <div className="text-xs text-muted-foreground">
                    Fonte: {attraction.source === 'osm' ? 'OpenStreetMap' : attraction.source}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !searchLoading && attractions.length === 0 && (
          <div className="text-center py-12">
            <Camera className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">
              {isSearchMode ? "Nenhuma atração encontrada" : "Nenhuma atração disponível"}
            </h3>
            <p className="text-muted-foreground mb-4">
              {isSearchMode 
                ? `Não encontramos atrações para "${searchQuery}" em ${selectedCity}`
                : `Não há atrações disponíveis em ${selectedCity} na categoria selecionada`
              }
            </p>
            <div className="flex gap-2 justify-center">
              {isSearchMode && (
                <Button 
                  onClick={() => setSearchQuery("")}
                  variant="outline"
                >
                  Limpar busca
                </Button>
              )}
              <Button 
                onClick={() => {
                  setSelectedCategory("all");
                  setSelectedCity("Belo Horizonte");
                  setSearchQuery("");
                }}
                variant="outline"
              >
                Ver todas as atrações
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}