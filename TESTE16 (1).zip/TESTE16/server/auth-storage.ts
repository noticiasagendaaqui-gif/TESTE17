import type { User, InsertUser, Settings, InsertSettings } from "@shared/auth-schema";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";

export interface IAuthStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(userData: InsertUser): Promise<User>;
  updateUser(id: string, userData: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  verifyPassword(password: string, hashedPassword: string): Promise<boolean>;
  
  // Settings
  getSettings(): Promise<Settings[]>;
  getSettingsByCategory(category: string): Promise<Settings[]>;
  getSetting(key: string): Promise<Settings | undefined>;
  setSetting(settingData: InsertSettings): Promise<Settings>;
  updateSetting(key: string, value: string): Promise<Settings | undefined>;
  deleteSetting(key: string): Promise<boolean>;
}

export class MemAuthStorage implements IAuthStorage {
  private users: Map<string, User> = new Map();
  private settings: Map<string, Settings> = new Map();

  constructor() {
    this.initializeData();
  }

  private async initializeData() {
    // Create default admin user
    const adminUser: User = {
      id: randomUUID(),
      username: "admin",
      email: "admin@lapabus.com",
      password: await bcrypt.hash("admin123", 10),
      role: "admin",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Initialize default settings
    const defaultSettings: InsertSettings[] = [
      {
        key: "app_name",
        value: "LapaBus",
        description: "Nome da aplicação",
        type: "string",
        category: "general",
        isPublic: true,
      },
      {
        key: "app_description",
        value: "Sistema de transporte público da região metropolitana de Belo Horizonte",
        description: "Descrição da aplicação",
        type: "string",
        category: "general",
        isPublic: true,
      },
      {
        key: "max_businesses_per_city",
        value: "50",
        description: "Máximo de empresas por cidade",
        type: "number",
        category: "limits",
        isPublic: false,
      },
      {
        key: "enable_user_registration",
        value: "false",
        description: "Permitir registro de novos usuários",
        type: "boolean",
        category: "auth",
        isPublic: false,
      },
      {
        key: "maintenance_mode",
        value: "false",
        description: "Modo de manutenção",
        type: "boolean",
        category: "system",
        isPublic: true,
      },
      {
        key: "contact_email",
        value: "contato@lapabus.com",
        description: "Email de contato",
        type: "string",
        category: "general",
        isPublic: true,
      },
      {
        key: "support_phone",
        value: "(31) 3000-0000",
        description: "Telefone de suporte",
        type: "string",
        category: "general",
        isPublic: true,
      },
    ];

    defaultSettings.forEach(settingData => {
      const setting: Settings = {
        id: randomUUID(),
        ...settingData,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.settings.set(setting.key, setting);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(userData: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const user: User = {
      id: randomUUID(),
      ...userData,
      password: hashedPassword,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: string, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser: User = {
      ...user,
      ...userData,
      updatedAt: new Date(),
    };

    if (userData.password) {
      updatedUser.password = await bcrypt.hash(userData.password, 10);
    }

    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(password, hashedPassword);
  }

  // Settings methods
  async getSettings(): Promise<Settings[]> {
    return Array.from(this.settings.values());
  }

  async getSettingsByCategory(category: string): Promise<Settings[]> {
    return Array.from(this.settings.values()).filter(setting => setting.category === category);
  }

  async getSetting(key: string): Promise<Settings | undefined> {
    return this.settings.get(key);
  }

  async setSetting(settingData: InsertSettings): Promise<Settings> {
    const setting: Settings = {
      id: randomUUID(),
      ...settingData,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.settings.set(setting.key, setting);
    return setting;
  }

  async updateSetting(key: string, value: string): Promise<Settings | undefined> {
    const setting = this.settings.get(key);
    if (!setting) return undefined;

    const updatedSetting: Settings = {
      ...setting,
      value,
      updatedAt: new Date(),
    };

    this.settings.set(key, updatedSetting);
    return updatedSetting;
  }

  async deleteSetting(key: string): Promise<boolean> {
    return this.settings.delete(key);
  }
}

export const authStorage = new MemAuthStorage();