import type { InsertBusiness } from "@shared/schema";
import fetch from "node-fetch";
import { randomUUID } from "crypto";

export interface ExternalBusinessData {
  name: string;
  address: string;
  category: string;
  subcategory?: string;
  phone?: string;
  website?: string;
  coordinates?: string;
  description?: string;
  rating?: number;
  priceRange?: string;
}

export interface CNPJData {
  cnpj: string;
  nome: string;
  email?: string;
  telefone?: string;
  endereco: {
    logradouro: string;
    numero: string;
    bairro: string;
    cidade: string;
    cep: string;
    uf: string;
  };
  atividade_principal: {
    codigo: string;
    texto: string;
  };
}

export interface FoursquareVenue {
  id: string;
  name: string;
  location: {
    address?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    lat: number;
    lng: number;
  };
  categories: Array<{
    id: string;
    name: string;
    shortName: string;
  }>;
  contact?: {
    phone?: string;
    formattedPhone?: string;
  };
  url?: string;
  rating?: number;
  price?: {
    tier: number;
  };
}

export interface NominatimPlace {
  place_id: number;
  display_name: string;
  lat: string;
  lon: string;
  address: {
    shop?: string;
    house_number?: string;
    road?: string;
    suburb?: string;
    city?: string;
    postcode?: string;
    state?: string;
    country?: string;
  };
  type: string;
  class: string;
}

export class ExternalBusinessService {
  private readonly nominatimUrl = "https://nominatim.openstreetmap.org";
  private readonly brasilApiUrl = "https://brasilapi.com.br/api";
  private readonly viaCepUrl = "https://viacep.com.br/ws";
  
  // Headers padrão para requisições
  private readonly headers = {
    'User-Agent': 'LapaBus/1.0 (Business Directory)',
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  };

  /**
   * Busca empresas por cidade usando Nominatim (OpenStreetMap)
   */
  async searchBusinessesByCity(cityName: string, state: string = "MG"): Promise<ExternalBusinessData[]> {
    try {
      const query = `${cityName}, ${state}, Brazil`;
      const amenities = ['restaurant', 'cafe', 'shop', 'pharmacy', 'hospital', 'school', 'hotel'];
      const businesses: ExternalBusinessData[] = [];

      for (const amenity of amenities) {
        const url = `${this.nominatimUrl}/search` +
          `?q=${encodeURIComponent(`${amenity} in ${query}`)}` +
          `&format=json&addressdetails=1&limit=10&extratags=1`;

        const response = await fetch(url, { headers: this.headers });
        if (!response.ok) continue;

        const places: NominatimPlace[] = await response.json();
        
        for (const place of places) {
          const business = this.convertNominatimToBusiness(place);
          if (business) {
            businesses.push(business);
          }
        }

        // Rate limiting - respeitar os limites da API
        await this.delay(1000);
      }

      return businesses;
    } catch (error) {
      console.error('Erro ao buscar empresas via Nominatim:', error);
      return [];
    }
  }

  /**
   * Busca dados de empresa por CNPJ usando BrasilAPI
   */
  async getBusinessByCNPJ(cnpj: string): Promise<ExternalBusinessData | null> {
    try {
      const cleanCNPJ = cnpj.replace(/\D/g, '');
      if (cleanCNPJ.length !== 14) {
        throw new Error('CNPJ deve ter 14 dígitos');
      }

      const url = `${this.brasilApiUrl}/cnpj/v1/${cleanCNPJ}`;
      const response = await fetch(url, { headers: this.headers });
      
      if (!response.ok) {
        throw new Error(`Erro na API BrasilAPI: ${response.status}`);
      }

      const cnpjData: CNPJData = await response.json();
      return this.convertCNPJToBusiness(cnpjData);
    } catch (error) {
      console.error('Erro ao buscar CNPJ:', error);
      return null;
    }
  }

  /**
   * Geocodifica um endereço usando Nominatim
   */
  async geocodeAddress(address: string, city?: string, state?: string): Promise<{ lat: number; lng: number } | null> {
    try {
      const fullAddress = [address, city, state, 'Brazil'].filter(Boolean).join(', ');
      const url = `${this.nominatimUrl}/search` +
        `?q=${encodeURIComponent(fullAddress)}` +
        `&format=json&limit=1`;

      const response = await fetch(url, { headers: this.headers });
      if (!response.ok) return null;

      const results: NominatimPlace[] = await response.json();
      if (results.length === 0) return null;

      const place = results[0];
      return {
        lat: parseFloat(place.lat),
        lng: parseFloat(place.lon)
      };
    } catch (error) {
      console.error('Erro na geocodificação:', error);
      return null;
    }
  }

  /**
   * Busca CEP usando ViaCEP
   */
  async getAddressByCEP(cep: string): Promise<{ address: string; neighborhood: string; city: string; state: string } | null> {
    try {
      const cleanCEP = cep.replace(/\D/g, '');
      if (cleanCEP.length !== 8) {
        throw new Error('CEP deve ter 8 dígitos');
      }

      const url = `${this.viaCepUrl}/${cleanCEP}/json/`;
      const response = await fetch(url, { headers: this.headers });
      
      if (!response.ok) return null;

      const data = await response.json();
      if (data.erro) return null;

      return {
        address: data.logradouro,
        neighborhood: data.bairro,
        city: data.localidade,
        state: data.uf
      };
    } catch (error) {
      console.error('Erro ao buscar CEP:', error);
      return null;
    }
  }

  /**
   * Busca empresas próximas a uma coordenada usando Nominatim
   */
  async searchNearbyBusinesses(lat: number, lng: number, radius: number = 1000): Promise<ExternalBusinessData[]> {
    try {
      // Nominatim reverse geocoding para encontrar empresas próximas
      const url = `${this.nominatimUrl}/reverse` +
        `?lat=${lat}&lon=${lng}&format=json&addressdetails=1&zoom=18`;

      const response = await fetch(url, { headers: this.headers });
      if (!response.ok) return [];

      const result = await response.json();
      
      // Buscar empresas em um raio específico
      const searchUrl = `${this.nominatimUrl}/search` +
        `?q=shop restaurant cafe pharmacy hospital` +
        `&format=json&addressdetails=1&limit=20` +
        `&bounded=1&viewbox=${lng-0.01},${lat+0.01},${lng+0.01},${lat-0.01}`;

      const searchResponse = await fetch(searchUrl, { headers: this.headers });
      if (!searchResponse.ok) return [];

      const places: NominatimPlace[] = await searchResponse.json();
      const businesses: ExternalBusinessData[] = [];

      for (const place of places) {
        const business = this.convertNominatimToBusiness(place);
        if (business) {
          businesses.push(business);
        }
      }

      return businesses;
    } catch (error) {
      console.error('Erro ao buscar empresas próximas:', error);
      return [];
    }
  }

  /**
   * Converte dados do Nominatim para formato de negócio
   */
  private convertNominatimToBusiness(place: NominatimPlace): ExternalBusinessData | null {
    try {
      const name = place.address?.shop || 
                   place.display_name.split(',')[0] || 
                   'Estabelecimento';

      const category = this.mapNominatimCategory(place.type, place.class);
      if (!category) return null;

      return {
        name: name.trim(),
        address: this.buildAddress(place.address),
        category: category.category,
        subcategory: category.subcategory,
        coordinates: `${place.lat},${place.lon}`,
        description: `Estabelecimento encontrado via OpenStreetMap - ${place.display_name}`,
        rating: 0
      };
    } catch (error) {
      console.error('Erro ao converter dados do Nominatim:', error);
      return null;
    }
  }

  /**
   * Converte dados do CNPJ para formato de negócio
   */
  private convertCNPJToBusiness(cnpjData: CNPJData): ExternalBusinessData {
    const category = this.mapCNAEToCategory(cnpjData.atividade_principal.codigo);
    
    return {
      name: cnpjData.nome,
      address: this.buildAddressFromCNPJ(cnpjData.endereco),
      category: category.category,
      subcategory: category.subcategory,
      phone: cnpjData.telefone,
      description: `${cnpjData.atividade_principal.texto} - Dados obtidos via Receita Federal`,
      rating: 0
    };
  }

  /**
   * Mapeia categorias do Nominatim para nossas categorias
   */
  private mapNominatimCategory(type: string, osmClass: string): { category: string; subcategory: string } | null {
    const mappings: Record<string, { category: string; subcategory: string }> = {
      'restaurant': { category: 'restaurants', subcategory: 'restaurant' },
      'cafe': { category: 'restaurants', subcategory: 'cafe' },
      'fast_food': { category: 'restaurants', subcategory: 'fastfood' },
      'pharmacy': { category: 'health', subcategory: 'pharmacy' },
      'hospital': { category: 'health', subcategory: 'hospital' },
      'clinic': { category: 'health', subcategory: 'clinic' },
      'hotel': { category: 'hotels', subcategory: 'hotel' },
      'guest_house': { category: 'hotels', subcategory: 'pousada' },
      'school': { category: 'education', subcategory: 'school' },
      'university': { category: 'education', subcategory: 'university' },
      'shop': { category: 'retail', subcategory: 'shop' },
      'supermarket': { category: 'retail', subcategory: 'supermarket' },
      'hairdresser': { category: 'services', subcategory: 'salon' },
      'mechanic': { category: 'services', subcategory: 'mechanic' },
      'tourist_attraction': { category: 'leisure', subcategory: 'attraction' },
      'museum': { category: 'leisure', subcategory: 'museum' }
    };

    return mappings[type] || mappings[osmClass] || { category: 'services', subcategory: 'general' };
  }

  /**
   * Mapeia código CNAE para nossas categorias
   */
  private mapCNAEToCategory(cnae: string): { category: string; subcategory: string } {
    const cnaeCode = cnae.substring(0, 2); // Primeiros 2 dígitos
    
    const mappings: Record<string, { category: string; subcategory: string }> = {
      '56': { category: 'restaurants', subcategory: 'restaurant' },
      '55': { category: 'hotels', subcategory: 'hotel' },
      '47': { category: 'retail', subcategory: 'shop' },
      '86': { category: 'health', subcategory: 'clinic' },
      '85': { category: 'education', subcategory: 'school' },
      '49': { category: 'transport', subcategory: 'transport' },
      '96': { category: 'services', subcategory: 'personal' },
      '93': { category: 'leisure', subcategory: 'sports' },
      '79': { category: 'leisure', subcategory: 'tourism' }
    };

    return mappings[cnaeCode] || { category: 'services', subcategory: 'general' };
  }

  /**
   * Constrói endereço a partir dos dados do Nominatim
   */
  private buildAddress(address: any): string {
    const parts = [];
    if (address.road) parts.push(address.road);
    if (address.house_number) parts.push(address.house_number);
    return parts.join(', ') || 'Endereço não informado';
  }

  /**
   * Constrói endereço a partir dos dados do CNPJ
   */
  private buildAddressFromCNPJ(endereco: CNPJData['endereco']): string {
    const parts = [];
    if (endereco.logradouro) parts.push(endereco.logradouro);
    if (endereco.numero) parts.push(endereco.numero);
    if (endereco.bairro) parts.push(endereco.bairro);
    return parts.join(', ') || 'Endereço não informado';
  }

  /**
   * Delay para rate limiting
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Valida se uma empresa já existe no sistema
   */
  validateBusinessData(data: ExternalBusinessData): boolean {
    return !!(data.name && data.address && data.category);
  }

  /**
   * Converte dados externos para formato de inserção no banco
   */
  convertToInsertBusiness(
    data: ExternalBusinessData, 
    cityId: string, 
    neighborhood?: string,
    postalCode?: string
  ): InsertBusiness {
    return {
      cityId,
      name: data.name,
      slug: this.generateSlug(data.name),
      category: data.category,
      subcategory: data.subcategory,
      phone: data.phone,
      website: data.website,
      address: data.address,
      neighborhood: neighborhood || 'Centro',
      postalCode: postalCode,
      coordinates: data.coordinates,
      description: data.description,
      priceRange: data.priceRange || '$$',
      rating: data.rating || 0,
      reviewCount: 0,
      isVerified: false,
      isActive: true
    };
  }

  /**
   * Gera slug a partir do nome
   */
  private generateSlug(name: string): string {
    return name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '') // Remove acentos
      .replace(/[^a-z0-9\s-]/g, '') // Remove caracteres especiais
      .replace(/\s+/g, '-') // Substitui espaços por hífens
      .replace(/-+/g, '-') // Remove hífens duplos
      .replace(/^-|-$/g, ''); // Remove hífens do início e fim
  }
}

export const externalBusinessService = new ExternalBusinessService();