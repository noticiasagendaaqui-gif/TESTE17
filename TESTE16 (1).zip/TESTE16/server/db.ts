import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from "@shared/schema";

// Database configuration is optional - app will use in-memory storage if DATABASE_URL is not set
if (!process.env.DATABASE_URL) {
  console.log("No DATABASE_URL found, will use in-memory storage instead");
}

// Configuration for external PostgreSQL databases
// Works with: Supabase, Neon, Railway, Render, PlanetScale, etc.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

export { pool };
export const db = drizzle({ client: pool, schema });
