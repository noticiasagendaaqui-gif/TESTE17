import axios from 'axios';

export interface Event {
  id: string;
  title: string;
  description?: string;
  artist?: string;
  venue: {
    name: string;
    address: string;
    city: string;
    region?: string;
    country: string;
    latitude?: number;
    longitude?: number;
  };
  datetime: string;
  date: string;
  time?: string;
  category: string;
  genre?: string;
  url?: string;
  ticketUrl?: string;
  imageUrl?: string;
  priceRange?: {
    min?: number;
    max?: number;
    currency: string;
  };
  source: 'bandsintown' | 'ticketmaster';
  sourceId: string;
  popularity?: number;
  availability?: 'available' | 'soldout' | 'cancelled';
}

export interface EventSearchOptions {
  location?: string;
  city?: string;
  artist?: string;
  date?: string;
  radius?: number;
  category?: string;
  limit?: number;
  startDate?: string;
  endDate?: string;
}

export class EventsService {
  private bandsinTownAppId = process.env.BANDSINTOWN_APP_ID || 'lapabus_events_app';
  private ticketmasterApiKey = process.env.TICKETMASTER_API_KEY;

  // Search events using Bandsintown API
  async searchBandsinTownEvents(options: EventSearchOptions): Promise<Event[]> {
    try {
      const events: Event[] = [];
      
      // Search by location
      if (options.location || options.city) {
        const location = options.city || options.location || 'Belo Horizonte,BR';
        const url = `https://rest.bandsintown.com/events?app_id=${this.bandsinTownAppId}&location=${encodeURIComponent(location)}`;
        
        const response = await axios.get(url, {
          timeout: 10000,
          headers: {
            'User-Agent': 'LapaBus Events App'
          }
        });

        if (response.data && Array.isArray(response.data)) {
          const bandsinTownEvents = response.data
            .slice(0, options.limit || 20)
            .map(event => this.mapBandsinTownEvent(event));
          events.push(...bandsinTownEvents);
        }
      }

      // Search by artist if specified
      if (options.artist) {
        const artistUrl = `https://rest.bandsintown.com/artists/${encodeURIComponent(options.artist)}/events?app_id=${this.bandsinTownAppId}`;
        
        try {
          const artistResponse = await axios.get(artistUrl, {
            timeout: 10000,
            headers: {
              'User-Agent': 'LapaBus Events App'
            }
          });

          if (artistResponse.data && Array.isArray(artistResponse.data)) {
            const artistEvents = artistResponse.data
              .slice(0, options.limit || 10)
              .map(event => this.mapBandsinTownEvent(event));
            events.push(...artistEvents);
          }
        } catch (error) {
          console.log(`Artist ${options.artist} not found on Bandsintown`);
        }
      }

      return events;
    } catch (error) {
      console.error('Error fetching Bandsintown events:', error);
      return [];
    }
  }

  // Search events using Ticketmaster API
  async searchTicketmasterEvents(options: EventSearchOptions): Promise<Event[]> {
    if (!this.ticketmasterApiKey) {
      console.log('Ticketmaster API key not configured');
      return [];
    }

    try {
      const params: any = {
        apikey: this.ticketmasterApiKey,
        size: options.limit || 20,
        sort: 'date,asc'
      };

      if (options.city) {
        params.city = options.city;
      }

      if (options.startDate) {
        params.startDateTime = options.startDate;
      }

      if (options.endDate) {
        params.endDateTime = options.endDate;
      }

      if (options.category) {
        params.classificationName = options.category;
      }

      const url = 'https://app.ticketmaster.com/discovery/v2/events.json';
      const response = await axios.get(url, {
        params,
        timeout: 10000,
        headers: {
          'User-Agent': 'LapaBus Events App'
        }
      });

      if (response.data && response.data._embedded && response.data._embedded.events) {
        return response.data._embedded.events.map(event => this.mapTicketmasterEvent(event));
      }

      return [];
    } catch (error) {
      console.error('Error fetching Ticketmaster events:', error);
      return [];
    }
  }

  // Search all events from multiple sources
  async searchAllEvents(options: EventSearchOptions): Promise<Event[]> {
    try {
      const results = await Promise.allSettled([
        this.searchBandsinTownEvents(options),
        this.searchTicketmasterEvents(options)
      ]);

      let allEvents: Event[] = [];

      results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          allEvents = allEvents.concat(result.value);
        } else {
          console.error(`Error in source ${index}:`, result.reason);
        }
      });

      // Remove duplicates and sort by date
      const uniqueEvents = this.removeDuplicateEvents(allEvents);
      return uniqueEvents.sort((a, b) => new Date(a.datetime).getTime() - new Date(b.datetime).getTime());
    } catch (error) {
      console.error('Error searching all events:', error);
      return [];
    }
  }

  // Get popular events for a city
  async getPopularEvents(city: string = 'Belo Horizonte'): Promise<Event[]> {
    const popularArtists = [
      'Anitta', 'Luan Santana', 'Marília Mendonça', 'Jorge e Mateus', 
      'Henrique e Juliano', 'Maiara e Maraisa', 'Gusttavo Lima',
      'Coldplay', 'Ed Sheeran', 'Maroon 5', 'Imagine Dragons'
    ];

    const events: Event[] = [];

    // Get events by location first
    const locationEvents = await this.searchBandsinTownEvents({
      city: `${city},BR`,
      limit: 15
    });
    events.push(...locationEvents);

    // Get some events from popular artists
    for (const artist of popularArtists.slice(0, 3)) {
      try {
        const artistEvents = await this.searchBandsinTownEvents({
          artist,
          limit: 3
        });
        events.push(...artistEvents);
      } catch (error) {
        // Continue with next artist
      }
    }

    return this.removeDuplicateEvents(events).slice(0, 20);
  }

  // Map Bandsintown event to our Event interface
  private mapBandsinTownEvent(event: any): Event {
    return {
      id: `bt_${event.id || Date.now()}_${Math.random()}`,
      title: event.title || `${event.artist?.name} em ${event.venue?.name}`,
      artist: event.artist?.name,
      venue: {
        name: event.venue?.name || 'Local não informado',
        address: `${event.venue?.street_address || ''}, ${event.venue?.city || ''}`.trim(),
        city: event.venue?.city || '',
        region: event.venue?.region || '',
        country: event.venue?.country || 'BR',
        latitude: parseFloat(event.venue?.latitude) || undefined,
        longitude: parseFloat(event.venue?.longitude) || undefined,
      },
      datetime: event.datetime,
      date: event.datetime ? new Date(event.datetime).toLocaleDateString('pt-BR') : '',
      time: event.datetime ? new Date(event.datetime).toLocaleTimeString('pt-BR', { 
        hour: '2-digit', 
        minute: '2-digit' 
      }) : undefined,
      category: 'Música',
      genre: event.artist?.genre || 'Não informado',
      url: event.url,
      ticketUrl: event.offers?.[0]?.url,
      imageUrl: event.artist?.image_url || event.artist?.thumb_url,
      source: 'bandsintown',
      sourceId: event.id?.toString() || '',
      popularity: event.artist?.tracker_count || 0,
      availability: event.offers?.length > 0 ? 'available' : 'soldout'
    };
  }

  // Map Ticketmaster event to our Event interface
  private mapTicketmasterEvent(event: any): Event {
    const venue = event._embedded?.venues?.[0] || {};
    const priceRange = event.priceRanges?.[0];
    
    return {
      id: `tm_${event.id}`,
      title: event.name,
      description: event.info,
      venue: {
        name: venue.name || 'Local não informado',
        address: `${venue.address?.line1 || ''}, ${venue.city?.name || ''}`.trim(),
        city: venue.city?.name || '',
        region: venue.state?.name || '',
        country: venue.country?.countryCode || 'BR',
        latitude: parseFloat(venue.location?.latitude) || undefined,
        longitude: parseFloat(venue.location?.longitude) || undefined,
      },
      datetime: event.dates?.start?.dateTime || event.dates?.start?.localDate,
      date: event.dates?.start?.localDate ? 
        new Date(event.dates.start.localDate).toLocaleDateString('pt-BR') : '',
      time: event.dates?.start?.localTime,
      category: event.classifications?.[0]?.segment?.name || 'Evento',
      genre: event.classifications?.[0]?.genre?.name,
      url: event.url,
      ticketUrl: event.url,
      imageUrl: event.images?.find(img => img.width > 300)?.url || event.images?.[0]?.url,
      priceRange: priceRange ? {
        min: priceRange.min,
        max: priceRange.max,
        currency: priceRange.currency || 'BRL'
      } : undefined,
      source: 'ticketmaster',
      sourceId: event.id,
      availability: event.dates?.status?.code === 'onsale' ? 'available' : 'soldout'
    };
  }

  // Remove duplicate events based on title and date
  private removeDuplicateEvents(events: Event[]): Event[] {
    const seen = new Set();
    return events.filter(event => {
      const key = `${event.title.toLowerCase()}_${event.date}_${event.venue.name.toLowerCase()}`;
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  // Get event categories
  getEventCategories() {
    return [
      { id: 'music', name: 'Música', icon: '🎵' },
      { id: 'sports', name: 'Esportes', icon: '⚽' },
      { id: 'theater', name: 'Teatro', icon: '🎭' },
      { id: 'comedy', name: 'Comédia', icon: '😄' },
      { id: 'family', name: 'Família', icon: '👨‍👩‍👧‍👦' },
      { id: 'arts', name: 'Artes', icon: '🎨' },
      { id: 'miscellaneous', name: 'Outros', icon: '🎪' }
    ];
  }

  // Validate event data
  validateEventData(event: any): boolean {
    return !!(
      event.title &&
      event.venue?.name &&
      event.datetime
    );
  }
}