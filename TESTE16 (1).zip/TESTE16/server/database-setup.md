# Configuração de Banco de Dados Externo

## Provedores Recomendados

### 1. **Supabase** (Recomendado)
- **Gratuito**: 500MB, 2 projetos
- **Website**: https://supabase.com
- **Configuração**:
  1. Crie conta no Supabase
  2. Crie novo projeto
  3. Vá em Settings > Database
  4. Copie a Connection string (URI)

### 2. **Neon** 
- **Gratuito**: 512MB, 1 projeto
- **Website**: https://neon.tech
- **Configuração**:
  1. Crie conta no Neon
  2. Crie novo projeto
  3. Copie a connection string

### 3. **Railway**
- **Trial**: $5 de crédito gratuito
- **Website**: https://railway.app
- **Configuração**:
  1. Crie conta no Railway
  2. Crie novo projeto PostgreSQL
  3. Copie DATABASE_URL das variáveis

### 4. **Render**
- **Gratuito**: 1GB, expira em 90 dias
- **Website**: https://render.com
- **Configuração**:
  1. Crie conta no Render
  2. Crie PostgreSQL database
  3. Copie External Database URL

## Como Configurar

### 1. Obtenha a DATABASE_URL
A URL deve estar no formato:
```
postgresql://usuario:senha@host:porta/database?sslmode=require
```

### 2. Configure as Variáveis de Ambiente
No seu servidor de hospedagem, adicione:
```bash
DATABASE_URL="sua_connection_string_aqui"
NODE_ENV="production"
```

### 3. Execute as Migrações
Após deploy, execute:
```bash
npm run db:push
```

## Exemplo de Configuração (Supabase)

1. **Criar projeto no Supabase**
2. **Obter connection string**: 
   ```
   postgresql://postgres.xxxx:[YOUR-PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres
   ```
3. **Configurar no .env** (desenvolvimento):
   ```
   DATABASE_URL="postgresql://postgres.xxxx:senha@aws-0-us-east-1.pooler.supabase.com:6543/postgres"
   ```
4. **Deploy e migrar**:
   ```bash
   npm run db:push
   ```

## Testando a Conexão

Para testar se a conexão está funcionando:
```bash
npm run db:push --dry-run
```

## Troubleshooting

### Erro SSL
Se tiver problemas de SSL, adicione `?sslmode=require` na URL:
```
postgresql://user:pass@host:port/db?sslmode=require
```

### Timeout de Conexão
Verifique se:
- URL está correta
- Credenciais estão corretas  
- Firewall permite conexões
- Plano do provedor inclui conexões externas